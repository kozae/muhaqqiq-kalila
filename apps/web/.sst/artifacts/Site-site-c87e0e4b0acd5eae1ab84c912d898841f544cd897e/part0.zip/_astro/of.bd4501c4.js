import{p as o,f as s}from"./facsimile-events.274a34f1.js";function f(){for(var a=[],r=0;r<arguments.length;r++)a[r]=arguments[r];var e=o(a);return s(a,e)}export{f as o};
