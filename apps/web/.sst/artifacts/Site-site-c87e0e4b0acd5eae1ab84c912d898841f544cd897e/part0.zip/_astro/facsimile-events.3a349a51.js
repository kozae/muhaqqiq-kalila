import{g as e}from"./route.09294d32.js";const r=new e;export{r as h};
