import{S as n,R as e}from"./transcription-selectors.9952b924.js";const t=new n,i=new e(1),s=[100,100,250,100,250,250,100,250,0],a=new e;export{a as e,t as h,s as i,i as r};
